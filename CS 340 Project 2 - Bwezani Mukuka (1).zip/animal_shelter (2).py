# Bwezani Mukuka
# CS 340
from pymongo import MongoClient

class AnimalShelter(object):

    def __init__(self, username, password):
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d/%s?authSource=admin'
            % (USER, PASS, HOST, PORT, DB)
        )

        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print("Insert failed:", e)
                return False
        else:
            return False

    def read(self, query):
        if query is not None:
            try:
                results = self.collection.find(query)
                return list(results)
            except Exception as e:
                print("Read failed:", e)
                return []
        else:
            return []
    def delete(self, query):
        """Delete documents that match the query."""
        try:
            return self.collection.delete_many(query).deleted_count
        except Exception:
            return 0
    def update(self, query, new_values):
        """Update documents that match the query. Returns number updated."""
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print("Update failed:", e)
            return 0
    

        
